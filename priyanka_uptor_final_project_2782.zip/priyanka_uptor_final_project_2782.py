#required libraries are installed
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score
from sklearn.cluster import KMeans

# Load the dataset
df = pd.read_csv("priyanka_uptor_final_project_2782.csv")
# Show basic info
print("Dataset Head:")
print(df.head())

# Check for null values
print("\nNull values:")
print(df.isnull().sum())

# Drop or fill missing values (filling 'Modification' with 'Unknown')
df['Modification'].fillna('Unknown', inplace=True)

# Encode categorical columns
categorical_cols = df.select_dtypes(include='object').columns
label_encoders = {}
for col in categorical_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

# Correlation Heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(df.corr(numeric_only=True), cmap='coolwarm', annot=False)
plt.title("Correlation Heatmap")
plt.show()

# Supervised Learning - Predicting 'Condition' (new vs used)
X = df.drop(['Condition'], axis=1)
y = df['Condition']  # Already encoded as numeric

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

lr = LogisticRegression()
lr.fit(X_train_scaled, y_train)
y_pred = lr.predict(X_test_scaled)

print("\n--- Supervised Learning Results (Predicting Condition) ---")
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

# Unsupervised Learning - KMeans clustering
X_cluster = df.select_dtypes(include=np.number)
kmeans = KMeans(n_clusters=3, random_state=42)
df['Cluster'] = kmeans.fit_predict(X_cluster)

print("\n--- Unsupervised Learning (KMeans) ---")
print("Cluster Counts:")
print(df['Cluster'].value_counts())

# Visualize clusters using first two PCA components
from sklearn.decomposition import PCA

pca = PCA(n_components=2)
components = pca.fit_transform(X_cluster)

plt.scatter(components[:, 0], components[:, 1], c=df['Cluster'], cmap='viridis')
plt.title("KMeans Clusters Visualization")
plt.xlabel("PCA 1")
plt.ylabel("PCA 2")
plt.show()
